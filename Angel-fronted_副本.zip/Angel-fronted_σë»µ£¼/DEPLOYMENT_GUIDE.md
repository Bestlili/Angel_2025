# Angel 前端项目部署文档

## 项目概述

本项目是一个使用 Vue 3 + Vite 构建的心理健康服务平台前端，包含首页、登录注册、各种心理测试、树洞、社区等功能模块。

## 环境要求

- Node.js 16.x 或更高版本
- npm 8.x 或更高版本

## 本地开发环境搭建

1. **克隆项目代码**
   ```bash
   git clone <项目仓库地址>
   cd Angel-fronted
   ```

2. **安装依赖**
   ```bash
   npm install
   ```

3. **启动开发服务器**
   ```bash
   npm run dev
   ```
   开发服务器将在 http://localhost:5173 启动

4. **预览构建结果**（可选）
   ```bash
   npm run build
   npm run preview
   ```

## 生产环境构建

### 1. 构建项目

```bash
npm run build
```

构建产物将生成在 `dist/` 目录下，包含优化后的静态文件。

### 2. 构建注意事项

- 确保已正确配置 `vite.config.js` 中的代理设置
- 构建前检查环境变量配置
- 如需自定义构建输出目录，可在 `vite.config.js` 中配置 `build.outDir`

## 部署方案

### 方案一：Nginx 部署

1. **安装 Nginx**
   ```bash
   # Ubuntu/Debian
   sudo apt update
   sudo apt install nginx
   
   # CentOS/RHEL
   sudo yum install nginx
   ```

2. **配置 Nginx**

   创建 Nginx 配置文件：
   ```bash
   sudo nano /etc/nginx/conf.d/angel.conf
   ```

   配置内容示例：
   ```nginx
   server {
       listen 80;
       server_name your-domain.com;  # 替换为您的域名或IP
       
       root /path/to/Angel-fronted/dist;  # 替换为构建后的dist目录路径
       index index.html;
       
       # 处理单页应用路由
       location / {
           try_files $uri $uri/ /index.html;
       }
       
       # 配置API代理（生产环境中可选，根据实际情况配置）
       location /api {
           proxy_pass http://your-backend-server:8080;  # 替换为后端服务地址
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
       }
   }
   ```

3. **启动 Nginx**
   ```bash
   sudo systemctl start nginx
   sudo systemctl enable nginx
   ```

### 方案二：使用 Docker 部署

1. **创建 Dockerfile**

   在项目根目录创建 `Dockerfile`：
   ```dockerfile
   # 构建阶段
   FROM node:16-alpine as builder
   WORKDIR /app
   COPY package*.json ./
   RUN npm install
   COPY . .
   RUN npm run build
   
   # 运行阶段
   FROM nginx:alpine
   COPY --from=builder /app/dist /usr/share/nginx/html
   
   # 复制自定义Nginx配置
   COPY nginx.conf /etc/nginx/conf.d/default.conf
   
   EXPOSE 80
   CMD ["nginx", "-g", "daemon off;"]
   ```

2. **创建 Nginx 配置文件**

   在项目根目录创建 `nginx.conf`：
   ```nginx
   server {
       listen 80;
       
       location / {
           root   /usr/share/nginx/html;
           index  index.html;
           try_files $uri $uri/ /index.html;
       }
       
       location /api {
           proxy_pass http://your-backend-server:8080;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
           proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
           proxy_set_header X-Forwarded-Proto $scheme;
       }
   }
   ```

3. **构建和运行 Docker 容器**
   ```bash
   docker build -t angel-fronted .
   docker run -d -p 80:80 angel-fronted
   ```

## 部署后的注意事项

1. **API 地址配置**
   - 确保生产环境中的 API 地址正确配置
   - 可考虑通过环境变量动态配置 API 地址

2. **HTTPS 配置**
   - 生产环境建议配置 HTTPS
   - 可通过 Nginx 配置 SSL 证书

3. **性能优化**
   - 考虑启用 Gzip 压缩
   - 配置浏览器缓存策略

4. **监控与日志**
   - 配置适当的访问日志
   - 考虑添加错误监控

## 常见问题排查

1. **页面空白或路由错误**
   - 确保 Nginx 配置了正确的 `try_files` 指令
   - 检查 `router/index.js` 中的路由配置

2. **API 请求失败**
   - 检查网络连接
   - 确认 API 地址配置正确
   - 检查 CORS 配置

3. **构建失败**
   - 确保 Node.js 版本符合要求
   - 删除 `node_modules` 并重新安装依赖

## 维护与更新

1. **代码更新**
   ```bash
   git pull
   npm install
   npm run build
   ```

2. **重新部署**
   - 如使用 Nginx，复制新的构建产物到部署目录
   - 如使用 Docker，重新构建镜像并运行

---

如有任何问题，请联系开发团队。