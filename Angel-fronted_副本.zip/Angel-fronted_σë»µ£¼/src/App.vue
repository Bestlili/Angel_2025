<template>
    <router-view />
</template>

<style>
/* 全局样式重置（可选） */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Helvetica Neue', Arial, sans-serif;
}
</style>