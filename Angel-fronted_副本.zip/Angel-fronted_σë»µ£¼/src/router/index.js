import { createRouter, createWebHistory } from 'vue-router';
import HomeView from '../views/HomeView.vue';
import TestListView from '../views/TestListView.vue';
import EmotionTest from '../views/EmotionTest.vue';
import PersonalityTest from '../views/PersonalityTest.vue';
import RelationshipTest from '../views/RelationshipTest.vue';
import StressSourceTest from '../views/StressSourceTest.vue';
import SleepTest from '../views/SleepTest.vue';
import HappinessTest from '../views/HappinessTest.vue';
import TestResult from '../views/TestResult.vue';

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView,
    },
    {
      path: '/tests',
      name: 'tests',
      component: TestListView,
    },
    {
        path:'/login',
        name:'login',
        component: () => import('../views/LoginView.vue')
    },
    {
        path:'/register',
        name:'register',
        component: () => import('../views/RegisterView.vue')
    },
    {
        path:'/treehole',
        name:'treehole',
        component: () => import('../views/TreeholeView.vue')
    },
    {
        path:'/diary',
        name:'diary',
        component: () => import('../views/DiaryView.vue')
    },
    {
      path: '/emotion-test',
      name: 'emotionTest',
      component: EmotionTest,
    },
    {
      path: '/personality-test',
      name: 'personalityTest',
      component: PersonalityTest,
    },
    {
      path: '/relationship-test',
      name: 'relationshipTest',
      component: RelationshipTest,
    },
    {
      path: '/stress-source-test',
      name: 'stressSourceTest',
      component: StressSourceTest,
    },
    {
      path: '/sleep-test',
      name: 'sleepTest',
      component: SleepTest,
    },
    {
      path: '/happiness-test',
      name: 'happinessTest',
      component: HappinessTest,
    },
    {
      path: '/tests/result',
      name: 'testResult',
      component: TestResult,
    },
    {
        path:'/community',
        name:'community',
        component: () => import('../views/CommunityView.vue')
    },
    {
        path:'/account-settings',
        name:'accountSettings',
        component: () => import('../views/AccountSettings.vue')
    },
  ],
});

export default router;